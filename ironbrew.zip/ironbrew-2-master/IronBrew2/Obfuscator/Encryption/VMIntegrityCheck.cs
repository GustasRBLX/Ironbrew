namespace IronBrew2.Obfuscator.Encryption
{
	public class VMIntegrityCheck
	{
			
	}
}