namespace IronBrew2.Obfuscator
{
	public class CustomInstructionData
	{
		public VOpcode Opcode;
		public VOpcode WrittenOpcode;
	}
}